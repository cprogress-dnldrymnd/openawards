<div class="courses-holder">
	<div class="heading-box">
		<h3>
			My Courses
		</h3>
	</div>
	<?= do_shortcode('[my_purchased_products]') ?>
</div>