<section class="breadcrumbs wocom">
    <nav aria-label="breadcrumb">
        <div class="container<?= container_width() ?>">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?= get_site_url() ?>">Home</a></li>
                <li class="breadcrumb-item"><span><?php the_title() ?></span></li>
            </ol>
        </div>
    </nav>
</section>