# Assets

The `assets/` folder contains all referenced assets (images, videos, fonts, etc.)