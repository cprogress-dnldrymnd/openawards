<div class="upcoming-event-box list-box">
	<h3>Upcoming Events</h3>
	<?= do_shortcode( '<ul>[events_list]<li> <a href="#_EVENTURL">#_EVENTNAME <span>#_{d F Y}</span></a> </li>[/events_list]</ul>' ) ?>
</div>