<div class="event-category-box list-box">
	<h3>Categories</h3>
	<ul>
		<?= do_shortcode( '[categories_list hide_empty=0]<li>#_CATEGORYLINK</li>[/categories_list]' ) ?>
	</ul>
</div>